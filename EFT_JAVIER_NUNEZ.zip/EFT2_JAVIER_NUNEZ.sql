----- INFORME 1 -----

CREATE OR REPLACE VIEW RESUMEN_CLIENTES_POR_REGION AS
SELECT
    NOMBRE_REGION AS NOM_REGION,
    COUNT(CASE 
        WHEN TRUNC(MONTHS_BETWEEN(SYSDATE, FECHA_INSCRIPCION) / 12) >= 20 THEN 1 END) AS CANTIDAD_CLIENTES_MAYOR_20_ANNIOS,
    COUNT(*) AS CANTIDAD_TOTAL_CLIENTES
FROM
    CLIENTE
INNER JOIN
    REGION ON CLIENTE.COD_REGION = REGION.COD_REGION    
GROUP BY 
    NOMBRE_REGION
HAVING 
    COUNT(CASE
        WHEN TRUNC(MONTHS_BETWEEN(SYSDATE, FECHA_INSCRIPCION) / 12) >= 20 THEN 1 END) > 0
ORDER BY 
    CANTIDAD_CLIENTES_MAYOR_20_ANNIOS ASC;


SELECT * FROM RESUMEN_CLIENTES_POR_REGION;

CREATE INDEX IDX_REGION ON CLIENTE (cod_region);
CREATE INDEX IDX_CLI_REGION ON CLIENTE (cod_region, numrun);


EXPLAIN PLAN FOR
SELECT * FROM RESUMEN_CLIENTES_POR_REGION;
SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY);



---- INFORME 2 -----

-- ALTERNATIVA 1 - OPERADOR SET --

CREATE OR REPLACE VIEW TRANSACCIONES_SEGUNDO_SEMESTRE AS
SELECT
    TO_CHAR(SYSDATE, 'DD-MM-YYYY') AS FECHA,
    t.cod_tptran_tarjeta AS CODIGO,
    UPPER(t.nombre_tptran_tarjeta) AS DESCRIPCION,
    TRUNC(AVG (trans_tarj_c.monto_transaccion)) AS MONTO_PROMEDIO_TRANSACCION
FROM
    transaccion_tarjeta_cliente trans_tarj_c
INNER JOIN
    cuota_transac_tarjeta_cliente c_trans_tarj_c ON trans_tarj_c.nro_tarjeta = c_trans_tarj_c.nro_tarjeta AND trans_tarj_c.nro_transaccion = c_trans_tarj_c.nro_transaccion
INNER JOIN
    tipo_transaccion_tarjeta t ON trans_tarj_c.cod_tptran_tarjeta = t.cod_tptran_tarjeta
WHERE
    EXTRACT(MONTH FROM c_trans_tarj_c.fecha_venc_cuota) BETWEEN 6 AND 12
GROUP BY
    t.cod_tptran_tarjeta, t.nombre_tptran_tarjeta
ORDER BY
    AVG(trans_tarj_c.monto_transaccion) ASC;
    
SELECT * FROM TRANSACCIONES_SEGUNDO_SEMESTRE;
    
-- ALTERNATIVA 2 - SUBCONSULTA --

CREATE TABLE SELECCIÓN_TIPO_TRANSACCIÓN (
    FECHA DATE,
    COD_TIPO_TRANSAC NUMBER,
    NOMBRE_TIPO_TRANSAC VARCHAR2(100),
    MONTO_PROMEDIO NUMBER
);

INSERT INTO SELECCIÓN_TIPO_TRANSACCIÓN (FECHA, COD_TIPO_TRANSAC, NOMBRE_TIPO_TRANSAC, MONTO_PROMEDIO)
SELECT
    TO_CHAR(SYSDATE, 'DD-MM-YYYY') AS FECHA,
    t.cod_tptran_tarjeta AS COD_TIPO_TRANSAC,
    UPPER(t.nombre_tptran_tarjeta) AS NOMBRE_TIPO_TRANSAC,
    TRUNC(AVG(trans_tarj_c.monto_transaccion)) AS MONTO_PROMEDIO
FROM
    transaccion_tarjeta_cliente trans_tarj_c
INNER JOIN
    cuota_transac_tarjeta_cliente c_trans_tarj_c ON trans_tarj_c.nro_tarjeta = c_trans_tarj_c.nro_tarjeta AND trans_tarj_c.nro_transaccion = c_trans_tarj_c.nro_transaccion
INNER JOIN
    tipo_transaccion_tarjeta t ON trans_tarj_c.cod_tptran_tarjeta = t.cod_tptran_tarjeta
WHERE
    EXTRACT(MONTH FROM c_trans_tarj_c.fecha_venc_cuota) BETWEEN 6 AND 12
GROUP BY
    t.cod_tptran_tarjeta, t.nombre_tptran_tarjeta;
    
COMMIT;

SELECT * FROM SELECCIÓN_TIPO_TRANSACCIÓN
ORDER BY MONTO_PROMEDIO ASC;


-- Actualización ti basada en SELECCIÓN_TIPO_TRANSACCIÓN --
UPDATE tipo_transaccion_tarjeta t
SET t.tasaint_tptran_tarjeta = TRUNC(t.tasaint_tptran_tarjeta * 0.99, 2)
WHERE EXISTS (
    SELECT 1
    FROM SELECCIÓN_TIPO_TRANSACCIÓN sel_t_trans
    WHERE sel_t_trans.cod_tipo_transac = t.cod_tptran_tarjeta
);

COMMIT;

SELECT 
    COD_TPTRAN_TARJETA, 
    NOMBRE_TPTRAN_TARJETA, 
    TO_CHAR(TASAINT_TPTRAN_TARJETA, 'FM9990.90', 'NLS_NUMERIC_CHARACTERS = '',.''') AS TASAINT_TPTRAN_TARJETA, 
    NRO_MAXIMO_CUOTAS_TRAN, 
    COD_PRODUCTO 
FROM 
    TIPO_TRANSACCION_TARJETA
ORDER BY COD_TPTRAN_TARJETA ASC;


SELECT * FROM SELECCIÓN_TIPO_TRANSACCIÓN;
    

/*UPDATE tipo_transaccion_tarjeta t
SET t.tasaint_tptran_tarjeta = t.tasaint_tptran_tarjeta / 0.99
WHERE EXISTS (
    SELECT 1
    FROM SELECCIÓN_TIPO_TRANSACCIÓN sel_t_trans
    WHERE sel_t_trans.cod_tipo_transac = t.cod_tptran_tarjeta
);

-- Confirmar la transacción
COMMIT;

*/


/*---- RESPUESTAS -----

1. ¿Cuál es el problema que se debe resolveRr
El problema a resolver es identificar y analizar las transacciones de clientes cuya fecha de vencimiento de cuotas cae en el segundo semestre del año (junio a diciembre). 
Específicamente, se desea obtener un resumen que muestre la descripción de la transacción y el promedio de los montos de estas transacciones, 
además de actualizar las tasas de interés en la tabla correspondiente.


2. ¿Cuál es la información significativa que necesita para resolver el problema?

La información necesaria para resolver el problema es:

- Descripción de la transacción (nombre del tipo de transacción).
- Fechas de vencimiento de las cuotas.
- Montos de las cuotas de las transacciones.
- Tasas de interés aplicables a los tipos de transacciones.
- Identificadores de las transacciones y sus tipos.

Las últimas 2 son aplicables para el cálculo de la tasa de interés.

3. ¿Cuál es el propósito de la solución que se requiere?

El propósito es:

Visualizar las transacciones con vencimientos entre junio y diciembre, mostrando la descripción y el promedio de los montos independientemente del año.
También se deben ordenar los resultados por el monto promedio de transacciones en forma ascendente.
Por otro lado, las instrucciones solicitan generar dos alternativas de solución: una utilizando operadores SET y otra utilizando subconsultas.
Finalmente se debe actualizar la tasa de interés de la tabla tipo_transaccion_tarjeta aplicando una rebaja del 1% basada en los datos obtenidos, según lo requerido en las instrucciones.

4. Detalle los pasos, en lenguaje natural, necesarios para construir la alternativa que usa SUBCONSULTA.

Para construir la alternativa que usa subconsulta, se deben seguir estos pasos:

1) Crear una tabla llamada SELECCIÓN_TIPO_TRANSACCIÓN para almacenar los resultados de la subconsulta.
2) Insertar los datos en la tabla SELECCIÓN_TIPO_TRANSACCIÓN usando una subconsulta. 
La subconsulta debe seleccionar la fecha actual, el código del tipo de transacción, 
la descripción del tipo de transacción y el promedio de los montos de las cuotas cuyo vencimiento es entre junio y diciembre.
3) Realizar un COMMIT para confirmar la transacción y asegurar que los datos se guardan en la tabla SELECCIÓN_TIPO_TRANSACCIÓN.
4) Seleccionar y mostrar los datos de la tabla SELECCIÓN_TIPO_TRANSACCIÓN, ordenados por el promedio de los montos de las transacciones en forma ascendente.
5) Actualizar la tasa de interés en la tabla tipo_transaccion_tarjeta aplicando una rebaja del 1% utilizando los datos en SELECCIÓN_TIPO_TRANSACCIÓN.

5. Detalle los pasos, en lenguaje natural, necesarios para construir la alternativa que usa OPERADOR SET.

Para la alternativa que usa operadores SET, se deben seguir estos pasos:

1) Crear una vista llamada TRANSACCIONES_SEGUNDO_SEMESTRE que seleccione la fecha actual, el código del tipo de transacción, 
la descripción del tipo de transacción y el promedio de los montos de las cuotas cuyo vencimiento es entre junio y diciembre.
2) Usar operadores SET para combinar los resultados de diferentes consultas si es necesario (por ejemplo, UNION, INTERSECT).
3) Ordenar los resultados por el promedio de los montos de las transacciones en forma ascendente.
4) Mostrar los datos de la vista TRANSACCIONES_SEGUNDO_SEMESTRE.
5) Actualizar la tasa de interés en la tabla tipo_transaccion_tarjeta aplicando una rebaja del 1% utilizando los datos obtenidos de la vista TRANSACCIONES_SEGUNDO_SEMESTRE.
*/