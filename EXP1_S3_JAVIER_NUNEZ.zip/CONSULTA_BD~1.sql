CREATE TABLE Empleados (
    empleado_id NUMBER PRIMARY KEY,
    nombre VARCHAR2(255),
    departamento VARCHAR2(100),
    fecha_contratacion DATE,
    salario NUMBER(10, 2)
);

CREATE SEQUENCE empleado_seq START WITH 1;

BEGIN
    INSERT INTO Empleados (empleado_id, nombre, departamento, fecha_contratacion, salario) VALUES (empleado_seq.NEXTVAL, 'Carlos Martínez', 'Finanzas', TO_DATE('2010-04-01', 'YYYY-MM-DD'), 3000);
    INSERT INTO Empleados (empleado_id, nombre, departamento, fecha_contratacion, salario) VALUES (empleado_seq.NEXTVAL, 'María López', 'Recursos Humanos', TO_DATE('2012-07-15', 'YYYY-MM-DD'), 2500);
END;


SELECT AVG(salario) AS SALARIO_PROMEDIO, MAX(salario) AS SALARIO_MAXIMO, MIN(salario) AS SALARIO_MINIMO, departamento
FROM EMPLEADOS
GROUP BY departamento;

SELECT MAX(salario) AS SALARIO_MAS_ALTO, departamento
FROM EMPLEADOS
GROUP BY departamento;

SELECT EMPLEADOS.*, FLOOR(MONTHS_BETWEEN(SYSDATE,FECHA_CONTRATACION)/12) AS ANTIGUEDAD_ANIOS
FROM EMPLEADOS
WHERE (MONTHS_BETWEEN(SYSDATE,FECHA_CONTRATACION)/12) > 10;
