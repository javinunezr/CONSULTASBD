-- CASO 1 --

CREATE TABLE RECAUDACION_BONOS_MEDICOS (
    RUT_MEDICO      VARCHAR(20),
    NOMBRE_MEDICO   VARCHAR(100),
    TOTAL_RECAUDADO DECIMAL(10, 2),
    UNIDAD_MEDICA   VARCHAR(50)
);

COMMIT;
INSERT INTO RECAUDACION_BONOS_MEDICOS (
    RUT_MEDICO,
    NOMBRE_MEDICO,
    TOTAL_RECAUDADO,
    UNIDAD_MEDICA
)
SELECT
    m.rut_med || '-' || m.dv_run AS RUT_MEDICO,
    m.pnombre || ' ' || m.apaterno || ' ' || m.amaterno AS NOMBRE_MEDICO,
    SUM(bc.costo) AS TOTAL_RECAUDADO,
    uc.nombre AS UNIDAD_MEDICA
FROM 
    bono_consulta bc
JOIN 
    medico m ON bc.rut_med = m.rut_med
JOIN 
    UNIDAD_CONSULTA uc ON m.uni_id = uc.uni_id
    
WHERE m.car_id NOT IN (100,500,600) AND EXTRACT(YEAR FROM bc.fecha_bono) = EXTRACT(YEAR FROM SYSDATE) - 1

group by m.rut_med || '-' || m.dv_run, m.pnombre || ' ' || m.apaterno || ' ' || m.amaterno, uc.nombre
;

COMMIT;
SELECT * FROM RECAUDACION_BONOS_MEDICOS
ORDER BY TOTAL_RECAUDADO ASC;


-- CASO 2 -- 

SELECT 
    espmed.nombre AS ESPECIALIDAD_MEDICA,
    COUNT(bc.id_bono) AS CANTIDAD_BONOS,
    SUM(CASE 
            WHEN pagos.fecha_pago IS NULL THEN bc.costo
            ELSE 0
        END) AS MONTO_PERDIDA,
    MIN(bc.fecha_bono) AS FECHA_BONO,
    CASE 
        WHEN EXTRACT(YEAR FROM bc.fecha_bono) >= 2023 THEN 'COBRABLE' 
        ELSE 'INCOBRABLE'
    END AS ESTADO_DE_COBRO
FROM 
    BONO_CONSULTA bc
    JOIN DET_ESPECIALIDAD_MED despmed ON bc.rut_med = despmed.rut_med AND bc.esp_id = despmed.esp_id
    JOIN ESPECIALIDAD_MEDICA espmed ON despmed.esp_id = espmed.esp_id
    LEFT JOIN PAGOS pagos ON bc.id_bono = pagos.id_bono 
WHERE pagos.fecha_pago IS NULL
GROUP BY
    espmed.nombre, 
    CASE 
        WHEN EXTRACT(YEAR FROM bc.fecha_bono) >= 2023 THEN 'COBRABLE' 
        ELSE 'INCOBRABLE'
    END
ORDER BY
    CANTIDAD_BONOS ASC,
    MONTO_PERDIDA DESC;
    
    
-- CASO 3 --

INSERT INTO cant_bonos_pacientes_annio
    
WITH prombonos AS (
    SELECT 
        ROUND(AVG(costo)) AS prombonos
    FROM 
        BONO_CONSULTA
    WHERE 
        EXTRACT(YEAR FROM fecha_bono) = EXTRACT(YEAR FROM SYSDATE) -1
),

DatosPacientes AS (
    SELECT 
        EXTRACT(YEAR FROM SYSDATE) AS ANNIO_CALCULO, 
        pac.pac_run AS PAC_RUN,
        pac.dv_run AS DV_RUN,
        FLOOR((SYSDATE - pac.fecha_nacimiento) / 365.25) AS EDAD,
        bc.id_bono AS CANTIDAD_BONOS,
        COALESCE(bc.costo, 0) AS MONTO_TOTAL_BONOS,
        ss.descripcion AS SISTEMA_SALUD 
    FROM 
        PACIENTE pac
    LEFT JOIN 
        BONO_CONSULTA bc ON pac.pac_run = bc.pac_run        
    LEFT JOIN 
        SALUD s ON pac.sal_id = s.sal_id
    LEFT JOIN 
        SISTEMA_SALUD ss ON s.tipo_sal_id = ss.tipo_sal_id
    WHERE    
        EXTRACT(YEAR FROM bc.fecha_bono) = EXTRACT(YEAR FROM SYSDATE)
)
SELECT 
    datospac.ANNIO_CALCULO, 
    datospac.PAC_RUN, 
    datospac.DV_RUN, 
    datospac.EDAD, 
    COUNT (DISTINCT datospac.CANTIDAD_BONOS) AS CANTIDAD_BONOS, 
    SUM (datospac.MONTO_TOTAL_BONOS) AS MONTO_TOTAL_BONOS, 
    datospac.SISTEMA_SALUD
FROM 
    DatosPacientes datospac
CROSS JOIN 
    prombonos pb
WHERE 
    datospac.MONTO_TOTAL_BONOS <= pb.prombonos
GROUP BY
    datospac.ANNIO_CALCULO, 
    datospac.PAC_RUN, 
    datospac.DV_RUN, 
    datospac.EDAD,
    datospac.SISTEMA_SALUD
ORDER BY 
    COUNT (DISTINCT datospac.CANTIDAD_BONOS) ASC,
    datospac.EDAD DESC;
COMMIT;


SELECT * 
FROM CANT_BONOS_PACIENTES_ANNIO
WHERE ANNIO_CALCULO = EXTRACT(YEAR FROM SYSDATE)
ORDER BY CANTIDAD_BONOS ASC, EDAD DESC;
